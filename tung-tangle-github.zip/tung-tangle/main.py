from game.app import TungTangleApp

if __name__ == "__main__":
    TungTangleApp().run()
