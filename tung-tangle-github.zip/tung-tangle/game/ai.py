import random
from .models import Rival

NAMES = [
    ("Bloop", "Calm", 22, 24),
    ("Crag", "Aggressive", 31, 16),
    ("Zip", "Speedy", 18, 34),
    ("Moss", "Friendly", 20, 22),
    ("Grunt", "Aggressive", 35, 15),
    ("Nim", "Trickster", 23, 29),
]

def create_rivals(seed):
    rng = random.Random(seed)
    rivals = []
    for name, personality, might, agility in NAMES:
        bonus = rng.randint(0, 8)
        rivals.append(Rival(
            name=name,
            species="Wild Tung",
            might=might + bonus,
            agility=agility + rng.randint(0, 7),
            personality=personality,
        ))
    return rivals

def encounter_reaction(rival, player, rng):
    if rival.name in player.allies:
        return "ally"
    if rival.name in player.rivals:
        return "rival"

    roll = rng.random()
    if rival.personality == "Friendly" and roll < 0.65:
        player.allies.append(rival.name)
        rival.relationship += 2
        return "ally"
    if rival.personality == "Aggressive" or roll < 0.35:
        player.rivals.append(rival.name)
        rival.relationship -= 2
        return "rival"
    rival.relationship += 1
    return "neutral"
