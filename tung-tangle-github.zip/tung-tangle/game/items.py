ITEMS = {
    "Berry": {
        "description": "Restores 25 energy.",
        "energy": 25,
    },
    "Glow Fruit": {
        "description": "Restores 50 energy.",
        "energy": 50,
    },
    "Might Seed": {
        "description": "Permanently increases Might by 4.",
        "might": 4,
    },
    "Swift Leaf": {
        "description": "Permanently increases Agility by 4.",
        "agility": 4,
    },
}

def consume(tung, item_name):
    if not tung.use_item(item_name):
        return False, "You don't have that item."

    data = ITEMS[item_name]
    if "energy" in data:
        old = tung.energy
        tung.energy += data["energy"]
        tung.clamp()
        return True, f"{item_name} restored {tung.energy - old} energy."
    if "might" in data:
        tung.might += data["might"]
        tung.clamp()
        return True, f"{item_name} increased Might by {data['might']}."
    if "agility" in data:
        tung.agility += data["agility"]
        tung.clamp()
        return True, f"{item_name} increased Agility by {data['agility']}."
    return True, f"Used {item_name}."
