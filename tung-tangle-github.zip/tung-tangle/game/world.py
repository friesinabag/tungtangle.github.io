import random

LOCATIONS = {
    "Mossy Grove": {"energy": 0, "description": "A safe forest clearing full of berries."},
    "Crystal Caves": {"energy": -12, "description": "Beautiful caves with rare glowing fruit."},
    "Storm Ridge": {"energy": -18, "description": "A dangerous ridge where strong Tungs roam."},
    "Sunlit Marsh": {"energy": -8, "description": "Warm wetlands where Swift Tungs gather."},
}

def explore(state, rng=None):
    rng = rng or random.Random()
    tung = state.player
    location = tung.location
    cost = 12 + max(0, -LOCATIONS[location]["energy"])
    tung.energy -= cost

    roll = rng.random()
    if roll < 0.30:
        item = rng.choice(["Berry", "Berry", "Glow Fruit", "Might Seed", "Swift Leaf"])
        tung.add_item(item)
        tung.gain_xp(10)
        message = f"You explored {location} and found a {item}. Energy -{cost}."
    elif roll < 0.52:
        rival = rng.choice(state.rivals)
        message = f"You encountered {rival.name}, a {rival.personality} Tung."
    else:
        xp = rng.randint(6, 16)
        tung.gain_xp(xp)
        message = f"You explored {location}. Nothing unusual happened. XP +{xp}, Energy -{cost}."

    tung.clamp()
    state.add_log(message)
    return message

def train(state, stat, rng=None):
    rng = rng or random.Random()
    tung = state.player
    cost = 15
    if tung.energy < cost:
        return "You're too tired to train."
    tung.energy -= cost
    gain = rng.randint(2, 5)
    if stat == "might":
        tung.might += gain
        label = "Might"
    else:
        tung.agility += gain
        label = "Agility"
    tung.gain_xp(12)
    tung.clamp()
    message = f"Training complete: {label} +{gain}, XP +12, Energy -{cost}."
    state.add_log(message)
    return message

def rest(state):
    tung = state.player
    gain = min(tung.max_energy - tung.energy, 35)
    tung.energy += gain
    message = f"You rested and recovered {gain} energy."
    state.add_log(message)
    return message

def next_day(state):
    tung = state.player
    tung.day += 1
    drain = 4 + tung.day // 8
    tung.energy -= drain
    tung.clamp()
    state.add_log(f"Day {tung.day} begins. Overnight energy drain: {drain}.")
