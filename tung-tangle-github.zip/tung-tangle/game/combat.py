import random

def fight(player, rival, rng=None):
    rng = rng or random.Random()

    player_score = player.power + player.energy // 8 + rng.randint(0, 25)
    rival_score = rival.power + rng.randint(0, 25)

    if player.agility > rival.agility:
        player_score += 5

    if player_score >= rival_score:
        damage = rng.randint(8, 20)
        player.energy = max(0, player.energy - damage)
        player.wins += 1
        player.gain_xp(30)
        player.rivals = [x for x in player.rivals if x != rival.name]
        player.clamp()
        return True, f"You defeated {rival.name}! Energy -{damage}, XP +30."
    else:
        damage = rng.randint(12, 28)
        player.energy = max(0, player.energy - damage)
        player.losses += 1
        player.gain_xp(10)
        player.clamp()
        return False, f"{rival.name} won the encounter. Energy -{damage}, XP +10."

def spar(player, rival, rng=None):
    rng = rng or random.Random()
    player.energy = max(0, player.energy - 8)
    if rng.random() < 0.65:
        player.gain_xp(8)
        player.might += 1
        player.clamp()
        return f"You sparred with {rival.name}. Might +1, XP +8."
    player.gain_xp(5)
    return f"You sparred with {rival.name}. XP +5."
