import json
from pathlib import Path
from dataclasses import asdict
from .models import Tung, Rival, GameState

SAVE_PATH = Path("saves/save.json")

def save_game(state):
    SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = asdict(state)
    SAVE_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")

def load_game():
    if not SAVE_PATH.exists():
        return None
    data = json.loads(SAVE_PATH.read_text(encoding="utf-8"))
    player = Tung(**data["player"])
    rivals = [Rival(**r) for r in data["rivals"]]
    return GameState(
        player=player,
        rivals=rivals,
        world_seed=data.get("world_seed", 1),
        won=data.get("won", False),
        log=data.get("log", []),
        leaderboard=data.get("leaderboard", {}),
    )
