import random
import pygame
from .models import Tung, GameState
from .ai import create_rivals, encounter_reaction
from .world import LOCATIONS, explore, train, rest, next_day
from .combat import fight as do_fight
from .items import consume
from .save import save_game, load_game
from ui.screens import (
    MainScreen, InventoryScreen, TungsScreen, FightScreen,
    StatusScreen, TravelScreen, LeaderboardScreen, MessageScreen
)
from ui.theme import BG

class TungTangleApp:
    WIDTH, HEIGHT = 960, 640

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Tung Tangle")
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        self.clock = pygame.time.Clock()
        self.fonts = {
            "title": pygame.font.SysFont("arial", 34, bold=True),
            "h1": pygame.font.SysFont("arial", 30, bold=True),
            "h2": pygame.font.SysFont("arial", 22, bold=True),
            "h3": pygame.font.SysFont("arial", 18, bold=True),
            "body": pygame.font.SysFont("arial", 17),
            "small": pygame.font.SysFont("arial", 14),
            "emoji": pygame.font.SysFont("segoeuisymbol", 58),
        }
        self.rng = random.Random()
        self.locations = LOCATIONS
        self.state = self.new_game()
        self.screen_obj = MainScreen(self)

    def new_game(self):
        name = "Chomper"
        player = Tung(name=name)
        state = GameState(player=player, rivals=create_rivals(12345))
        state.add_log("Welcome to Tung Tangle. Your journey begins.")
        return state

    def set_screen(self, name):
        mapping = {
            "main": MainScreen, "inventory": InventoryScreen, "tungs": TungsScreen,
            "fight": FightScreen, "status": StatusScreen, "travel": TravelScreen,
            "leaderboard": LeaderboardScreen,
        }
        self.screen_obj = mapping[name](self)

    def do_explore(self):
        if self.state.player.energy < 10:
            self.set_message("Too Tired", "You need at least 10 energy to explore.")
            return
        message = explore(self.state, self.rng)
        self.after_action(message)

    def do_train(self, stat):
        message = train(self.state, stat, self.rng)
        self.after_action(message)

    def do_rest(self):
        message = rest(self.state)
        self.after_action(message)

    def use_item(self, item):
        ok, message = consume(self.state.player, item)
        if ok:
            self.state.add_log(message)
            self.after_action(message)
        else:
            self.set_message("Inventory", message)

    def fight(self, rival):
        if self.state.player.energy < 10:
            self.set_message("Too Tired", "Rest before fighting.")
            return
        won, message = do_fight(self.state.player, rival, self.rng)
        self.state.add_log(message)
        if won and self.state.player.wins >= 5 and self.state.player.evolution_level >= 3:
            self.state.won = True
            score = self.state.player.power + self.state.player.wins * 25 + self.state.player.day * 5
            self.state.leaderboard[self.state.player.name] = max(
                score, self.state.leaderboard.get(self.state.player.name, 0)
            )
            self.set_message("👑 ALPHA TUNG!", f"You defeated enough rivals and became the Alpha!\nScore: {score}")
        else:
            self.after_action(message)

    def travel(self, location):
        self.state.player.location = location
        self.state.player.energy = max(0, self.state.player.energy - 5)
        message = f"You travelled to {location}. Energy -5."
        self.state.add_log(message)
        self.after_action(message)

    def next_day(self):
        next_day(self.state)
        self.after_action(f"Day {self.state.player.day} has begun.")

    def after_action(self, message):
        evolved = self.state.player.check_evolution()
        if evolved:
            self.state.add_log(f"✨ Evolution! Your Tung is now a {self.state.player.species}.")
            self.set_message("✨ EVOLUTION!", f"{self.state.player.name} evolved into {self.state.player.species}!")
        elif self.state.player.energy <= 0:
            self.state.player.energy = 10
            self.set_message("Exhausted", "Your Tung is exhausted. A small emergency recovery restored 10 energy.")
        else:
            self.set_screen("main")

    def set_message(self, title, message):
        self.screen_obj = MessageScreen(self, title, message)

    def save(self):
        save_game(self.state)
        self.set_message("Saved", "Your game has been saved to saves/save.json.")

    def load(self):
        loaded = load_game()
        if loaded:
            self.state = loaded
            self.set_screen("main")
        else:
            self.set_message("Load", "No save file exists yet.")

    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.set_screen("main")
                    elif event.key == pygame.K_F5:
                        self.save()
                    elif event.key == pygame.K_F9:
                        self.load()
                    elif event.key == pygame.K_q:
                        running = False
                self.screen_obj.handle(event)

            self.screen.fill(BG)
            self.screen_obj.draw(self.screen)
            pygame.display.flip()
            self.clock.tick(60)

        pygame.quit()
