from dataclasses import dataclass, field
from typing import List, Dict
import random

@dataclass
class Tung:
    name: str
    species: str = "Common Tung"
    day: int = 1
    energy: int = 100
    max_energy: int = 100
    might: int = 20
    agility: int = 20
    power: int = 40
    wins: int = 0
    losses: int = 0
    evolution_level: int = 0
    inventory: List[str] = field(default_factory=lambda: ["Berry", "Berry"])
    allies: List[str] = field(default_factory=list)
    rivals: List[str] = field(default_factory=list)
    location: str = "Mossy Grove"
    xp: int = 0

    def clamp(self):
        self.energy = max(0, min(self.energy, self.max_energy))
        self.might = max(1, self.might)
        self.agility = max(1, self.agility)
        self.power = self.might + self.agility
        self.xp = max(0, self.xp)

    def add_item(self, item: str):
        self.inventory.append(item)

    def use_item(self, item: str) -> bool:
        if item in self.inventory:
            self.inventory.remove(item)
            return True
        return False

    def gain_xp(self, amount: int):
        self.xp += amount

    def check_evolution(self):
        thresholds = [0, 80, 150, 250]
        names = ["Common Tung", "Swift Tung", "Mighty Tung", "Alpha Tung"]
        changed = False
        while self.evolution_level < len(thresholds) - 1 and self.power >= thresholds[self.evolution_level + 1]:
            self.evolution_level += 1
            self.species = names[self.evolution_level]
            self.max_energy += 15
            self.energy = self.max_energy
            self.might += 5
            self.agility += 5
            changed = True
        self.clamp()
        return changed

@dataclass
class Rival:
    name: str
    species: str
    might: int
    agility: int
    personality: str
    relationship: int = 0

    @property
    def power(self):
        return self.might + self.agility

@dataclass
class GameState:
    player: Tung
    rivals: List[Rival]
    world_seed: int = field(default_factory=lambda: random.randint(1, 999999))
    won: bool = False
    log: List[str] = field(default_factory=list)
    leaderboard: Dict[str, int] = field(default_factory=dict)

    def add_log(self, message: str):
        self.log.insert(0, message)
        self.log = self.log[:8]
