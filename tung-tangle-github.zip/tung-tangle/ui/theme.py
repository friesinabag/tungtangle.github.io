BG = (14, 16, 23)
PANEL = (25, 29, 40)
PANEL_2 = (33, 38, 52)
TEXT = (235, 239, 245)
MUTED = (155, 164, 179)
ACCENT = (110, 220, 160)
ACCENT_2 = (105, 170, 245)
WARNING = (245, 190, 80)
DANGER = (235, 100, 105)
WHITE = (255, 255, 255)

FONT = "arial"

def bar_color(ratio):
    if ratio > .55:
        return ACCENT
    if ratio > .25:
        return WARNING
    return DANGER
