import pygame
from .components import Button, panel, text, stat_bar
from .theme import *

class BaseScreen:
    def __init__(self, app):
        self.app = app
        self.buttons = []

    def handle(self, event):
        if event.type == pygame.MOUSEMOTION:
            for b in self.buttons:
                b.update(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for b in self.buttons:
                if b.clicked(event.pos):
                    b.action()

    def draw_header(self, screen, title, subtitle=""):
        text(screen, title, (35, 24), self.app.fonts["title"], TEXT)
        if subtitle:
            text(screen, subtitle, (37, 66), self.app.fonts["small"], MUTED)

class MainScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.refresh()

    def refresh(self):
        self.buttons = []
        a = self.app
        actions = [
            ("🌿 Explore", a.do_explore),
            ("💪 Train Might", lambda: a.do_train("might")),
            ("👟 Train Agility", lambda: a.do_train("agility")),
            ("😴 Rest", a.do_rest),
            ("🎒 Inventory", lambda: a.set_screen("inventory")),
            ("🤝 Tungs", lambda: a.set_screen("tungs")),
            ("⚔️ Fight", lambda: a.set_screen("fight")),
            ("📊 Status", lambda: a.set_screen("status")),
            ("🗺️ Travel", lambda: a.set_screen("travel")),
            ("💾 Save", a.save),
            ("▶ Next Day", a.next_day),
            ("🏆 Leaderboard", lambda: a.set_screen("leaderboard")),
        ]
        for i, (label, fn) in enumerate(actions):
            x = 35 + (i % 3) * 205
            y = 455 + (i // 3) * 55
            self.buttons.append(Button((x, y, 185, 43), label, fn))

    def draw(self, screen):
        self.refresh()
        p = self.app.state.player
        self.draw_header(screen, "TUNG TANGLE", f"DAY {p.day}  •  {p.location}")
        panel(screen, (30, 100, 585, 330))
        text(screen, "🦎", (60, 150), self.app.fonts["emoji"])
        text(screen, p.name, (135, 145), self.app.fonts["h1"])
        text(screen, p.species, (137, 188), self.app.fonts["small"], MUTED)
        stat_bar(screen, 135, 250, 430, 18, p.energy, p.max_energy, "Energy", self.app.fonts)
        text(screen, f"⚡ POWER  {p.power}", (135, 292), self.app.fonts["h2"], ACCENT)
        text(screen, f"💪 MIGHT  {p.might}", (135, 335), self.app.fonts["body"])
        text(screen, f"👟 AGILITY  {p.agility}", (350, 335), self.app.fonts["body"])
        text(screen, f"🏆 WINS {p.wins}   ❌ LOSSES {p.losses}   ✨ XP {p.xp}", (135, 380), self.app.fonts["small"], MUTED)

        panel(screen, (640, 100, 290, 330), "RECENT EVENTS", self.app.fonts)
        for i, log in enumerate(self.app.state.log[:7]):
            text(screen, "• " + log, (658, 145 + i*38), self.app.fonts["small"], TEXT)

        for b in self.buttons:
            b.draw(screen, self.app.fonts["body"])

class InventoryScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)

    def draw(self, screen):
        self.draw_header(screen, "INVENTORY", "Click an item to use it")
        self.buttons = []
        items = list(dict.fromkeys(self.app.state.player.inventory))
        for i, item in enumerate(items):
            count = self.app.state.player.inventory.count(item)
            self.buttons.append(Button((40, 110+i*62, 300, 48), f"{item} × {count}", lambda item=item: self.app.use_item(item)))
        self.buttons.append(Button((40, 400, 180, 45), "← Back", lambda: self.app.set_screen("main")))
        for b in self.buttons:
            b.update(pygame.mouse.get_pos()); b.draw(screen, self.app.fonts["body"])
        panel(screen, (380, 105, 500, 320), "ITEM INFO", self.app.fonts)
        text(screen, "Berry — restores 25 energy.", (400, 155), self.app.fonts["body"])
        text(screen, "Glow Fruit — restores 50 energy.", (400, 195), self.app.fonts["body"])
        text(screen, "Might Seed — Might +4.", (400, 235), self.app.fonts["body"])
        text(screen, "Swift Leaf — Agility +4.", (400, 275), self.app.fonts["body"])

class TungsScreen(BaseScreen):
    def draw(self, screen):
        self.draw_header(screen, "TUNGS", "Allies and rivals")
        self.buttons = []
        y = 115
        for r in self.app.state.rivals:
            status = "ALLY" if r.name in self.app.state.player.allies else ("RIVAL" if r.name in self.app.state.player.rivals else "NEUTRAL")
            panel(screen, (35, y, 850, 90))
            text(screen, f"{r.name}  •  {r.species}", (55, y+14), self.app.fonts["h2"])
            text(screen, f"{status}   {r.personality}   Power {r.power}   Might {r.might}   Agility {r.agility}", (55, y+52), self.app.fonts["small"], MUTED)
            y += 105
        self.buttons.append(Button((35, 560, 180, 45), "← Back", lambda: self.app.set_screen("main")))
        for b in self.buttons:
            b.draw(screen, self.app.fonts["body"])

class FightScreen(BaseScreen):
    def draw(self, screen):
        self.draw_header(screen, "ENCOUNTERS", "Choose a rival")
        self.buttons = []
        y = 115
        for r in self.app.state.rivals:
            if r.name in self.app.state.player.rivals or True:
                label = f"⚔️ {r.name}   Power {r.power}"
                self.buttons.append(Button((40, y, 390, 50), label, lambda r=r: self.app.fight(r)))
                y += 65
        self.buttons.append(Button((40, 540, 180, 45), "← Back", lambda: self.app.set_screen("main")))
        for b in self.buttons:
            b.update(pygame.mouse.get_pos()); b.draw(screen, self.app.fonts["body"])

class StatusScreen(BaseScreen):
    def draw(self, screen):
        p = self.app.state.player
        self.draw_header(screen, "STATUS", "Your Tung's progression")
        panel(screen, (35, 110, 850, 370))
        rows = [
            ("Name", p.name), ("Species", p.species), ("Day", p.day),
            ("Location", p.location), ("Energy", f"{p.energy}/{p.max_energy}"),
            ("Might", p.might), ("Agility", p.agility), ("Power", p.power),
            ("Wins", p.wins), ("Losses", p.losses), ("XP", p.xp),
            ("Evolution", f"Stage {p.evolution_level}/3"),
        ]
        for i, (k, v) in enumerate(rows):
            x = 60 if i < 6 else 450
            y = 135 + (i % 6) * 52
            text(screen, k, (x, y), self.app.fonts["small"], MUTED)
            text(screen, v, (x, y+20), self.app.fonts["body"])
        self.buttons = [Button((35, 520, 180, 45), "← Back", lambda: self.app.set_screen("main"))]
        for b in self.buttons: b.draw(screen, self.app.fonts["body"])

class TravelScreen(BaseScreen):
    def draw(self, screen):
        self.draw_header(screen, "TRAVEL", "Different locations have different risks")
        self.buttons = []
        locations = list(self.app.locations.items())
        for i, (name, info) in enumerate(locations):
            y = 120 + i*85
            self.buttons.append(Button((45, y, 390, 60), name, lambda name=name: self.app.travel(name)))
            text(screen, info["description"], (465, y+18), self.app.fonts["small"], MUTED)
        self.buttons.append(Button((45, 510, 180, 45), "← Back", lambda: self.app.set_screen("main")))
        for b in self.buttons:
            b.update(pygame.mouse.get_pos()); b.draw(screen, self.app.fonts["body"])

class LeaderboardScreen(BaseScreen):
    def draw(self, screen):
        self.draw_header(screen, "LEADERBOARD", "Your best runs")
        panel(screen, (35, 110, 850, 400))
        entries = sorted(self.app.state.leaderboard.items(), key=lambda x: x[1], reverse=True)
        if not entries:
            text(screen, "No recorded runs yet.", (60, 155), self.app.fonts["body"], MUTED)
        for i, (name, score) in enumerate(entries[:8]):
            text(screen, f"{i+1}. {name}", (60, 155+i*42), self.app.fonts["body"])
            text(screen, score, (650, 155+i*42), self.app.fonts["body"], ACCENT)
        self.buttons = [Button((35, 540, 180, 45), "← Back", lambda: self.app.set_screen("main"))]
        for b in self.buttons: b.draw(screen, self.app.fonts["body"])

class MessageScreen(BaseScreen):
    def __init__(self, app, title, message):
        super().__init__(app)
        self.title = title
        self.message = message
        self.buttons = [Button((360, 500, 220, 50), "Continue", lambda: app.set_screen("main"))]

    def draw(self, screen):
        self.draw_header(screen, self.title)
        panel(screen, (100, 150, 760, 260))
        text(screen, self.message, (135, 210), self.app.fonts["h2"])
        for b in self.buttons: b.draw(screen, self.app.fonts["body"])
