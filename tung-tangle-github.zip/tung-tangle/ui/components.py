import pygame
from .theme import *

class Button:
    def __init__(self, rect, text, action, enabled=True):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.action = action
        self.enabled = enabled
        self.hover = False

    def update(self, mouse):
        self.hover = self.rect.collidepoint(mouse)

    def draw(self, screen, font):
        base = PANEL_2 if self.enabled else (50, 50, 58)
        if self.hover and self.enabled:
            base = (45, 70, 68)
        pygame.draw.rect(screen, base, self.rect, border_radius=10)
        pygame.draw.rect(screen, ACCENT if self.enabled else MUTED, self.rect, 2, border_radius=10)
        surf = font.render(self.text, True, TEXT if self.enabled else MUTED)
        screen.blit(surf, surf.get_rect(center=self.rect.center))

    def clicked(self, pos):
        return self.enabled and self.rect.collidepoint(pos)

def panel(screen, rect, title=None, fonts=None):
    pygame.draw.rect(screen, PANEL, rect, border_radius=14)
    pygame.draw.rect(screen, (55, 62, 80), rect, 1, border_radius=14)
    if title and fonts:
        screen.blit(fonts["h3"].render(title, True, TEXT), (rect.x + 18, rect.y + 14))

def text(screen, value, pos, font, color=TEXT):
    screen.blit(font.render(str(value), True, color), pos)

def stat_bar(screen, x, y, w, h, value, maximum, label, fonts):
    ratio = max(0, min(1, value / maximum if maximum else 0))
    text(screen, f"{label}  {value}/{maximum}", (x, y - 22), fonts["small"])
    pygame.draw.rect(screen, (48, 53, 68), (x, y, w, h), border_radius=h//2)
    pygame.draw.rect(screen, bar_color(ratio), (x, y, int(w*ratio), h), border_radius=h//2)
