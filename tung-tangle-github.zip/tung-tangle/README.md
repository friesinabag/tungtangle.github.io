# 🦎 Tung Tangle

Tung Tangle is a small single-player survival/evolution game built with Python and Pygame.

You create a Tung, explore a changing world, manage energy, train your stats, collect items,
meet AI Tungs, build alliances, fight rivals, evolve, and eventually try to become the Alpha Tung.

## Features

- Custom graphical Pygame interface
- Day/night survival loop
- Energy, Might, Agility and Power stats
- Training and exploration
- Random encounters
- Inventory and consumable items
- AI Tungs with simple personalities
- Alliances and rivalry system
- Turn-based combat
- Evolution milestones
- Leaderboard
- Save/load system using JSON
- No external art required: the game uses procedural shapes and text

## Requirements

- Python 3.10+
- Pygame 2.6+

## Run

```bash
python -m pip install -r requirements.txt
python main.py
```

## Controls

- Mouse: navigate menus and select actions
- ESC: return to the previous screen
- F5: save
- F9: load
- Q: quit

## Project structure

```text
tung-tangle/
├── main.py
├── game/
│   ├── app.py
│   ├── models.py
│   ├── world.py
│   ├── combat.py
│   ├── ai.py
│   ├── items.py
│   └── save.py
├── ui/
│   ├── components.py
│   ├── screens.py
│   └── theme.py
├── assets/
├── saves/
├── requirements.txt
└── README.md
```

## Game loop

Each day you can perform actions such as exploring, training, resting, or using items.
Actions consume energy. The world can generate encounters, resources and rival events.

At power thresholds your Tung evolves. Reach the Alpha milestone and defeat enough rivals
to win the run.

## License

MIT
